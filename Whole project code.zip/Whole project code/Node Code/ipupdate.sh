#!/bin/sh
# ipupdate.sh

sudo python /home/pi/projectcode/ipaddress.py &
