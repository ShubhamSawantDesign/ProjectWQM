#This is python script used to update ipaddress of 
from requests import get
import requests
from time import sleep
import datetime
tempdatetimeobj = datetime.datetime.now()
now = str(datetime.datetime.now().time())
time = now[:8]
date = '{:%d-%m-%Y }'.format(datetime.datetime.now())
f = open("ipaddresslog.dat", "a")


def sendData(ipaddress, nodeid):
    data = {"nodeid": nodeid, "ipaddress": ipaddress}
    resp = requests.post('https://wqmweb.000webhostapp.com/iptrack.php', params=data)
    f.write("IP Address " + ipaddress + " Update request Completed Successfully on Date" + date + " and on Time" + time + "\n")


try:
     while True:
         node= 'N345'
         ip = get('https://api.ipify.org').text
         sendData(ipaddress=ip, nodeid=node)
         sleep(35)
except KeyboardInterrupt:
 print('unHandled Exception Occured')
