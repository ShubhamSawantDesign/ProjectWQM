#!/bin/sh
# launch.sh

sudo python /home/pi/projectcode/code.py &

