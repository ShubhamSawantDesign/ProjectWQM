<?php
session_start();
require_once("dbconnect.php");




if($_SESSION["token"]){
    


$sql = "SELECT * FROM login_table WHERE id=".$_SESSION['token'];
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    
    if($row = $result->fetch_assoc()) {
		
	


?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Welcome <?php echo $row['user_name']?> </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body>


<?php require('header.php'); ?>

<div class="container" style="margin-top:30px">
  <div class="row">
    <div class="col-sm-4">
      <h2>User Information</h2>
      <p>Name: <?php echo $row['user_name'] ?></p>
      <p>Last Login on: </p>
      
     
      <hr class="d-sm-none">
    </div>
    <div class="col-sm-8">
      
      <p>Read instruction before preceding </p>
      <p>1. Check Node Name</p>
      <p>2. Always verify Device Status</p>
      <br>
      
      <div class="container">
  <h2>List of Connected Node</h2>         
  <table class="table">
    <thead>
      <tr>
        <th>Node ID</th>
        <th>Location</th>
        <th>IP Address</th>
		<th>Graphs</th>
		<th>Live Temp Status</th>
		<th>Live PH Status</th>
		<th>Live Turbidity Values</th>
      </tr>
    </thead>
    
    <tbody>
    <?php
    
	$sqlnode = "SELECT * FROM table_node";
    $resultnode = $conn->query($sqlnode);

    if ($resultnode->num_rows > 0) {
    // output data of each row
    while($rownode = $resultnode->fetch_assoc()) {
	
    ?>
      <tr>
        <td><a  href="NodeStatus.php?node_id=<?php echo $rownode['node_id']; ?>"><?php echo $rownode['node_id']; ?></a></td>
        <td><?php echo $rownode['location'];?></td>
        <td><?php echo $rownode['ip_address'];?></td>
		<td><a href="processing.php?node_id=<?php echo $rownode['node_id']; ?>" >See Graph</a></td>
		<td><a href="http://<?php echo $rownode['ip_address'];?>/Temperature.php" target="_blank">Click Here</a></td>
		<td><a href="http://<?php echo $rownode['ip_address'];?>/webpanel/PhMeasure" target="_blank">Click Here</a></td>
		<td><a href="http://<?php echo $rownode['ip_address'];?>/webpanel/Turbidity" target="_blank">Click Here</a></td>
      </tr>
      <?php
        }
	}
      ?>
    </tbody>
  </table>
</div>
      
      
      
      
    
    
     </div>
  </div>
</div>

<?php require("footer.php")  ?>

</body>
</html>

<?php
  
  }
}
  
  
  
  }
   else {
	   header("location: index.php");
   }

?>