<?php
require_once('dbconnect.php');
session_start();

$node_id = $_GET['node_id'];
if($_SESSION["token"]){
    


$sql = "SELECT * FROM login_table WHERE id=".$_SESSION['token'];
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    
    if($row = $result->fetch_assoc()) {

    $sqlnode = "SELECT * FROM table_node WHERE node_id='$node_id'";
    $resultnode = $conn->query($sqlnode);

    if ($resultnode->num_rows > 0) {
    // output data of each row
    if($rownode = $resultnode->fetch_assoc()) {
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Node <?php echo $rownode['node_id']; ?></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body>


<?php require('header.php'); ?>

<div class="container" style="margin-top:30px">
  <div class="row">
    <div class="col-sm-4">
      <h2>Node Information</h2>
      <p>Node ID:<?php echo $rownode['node_id']; ?></p>
      <p>Node Location:<?php echo $rownode['location']; ?></p>
      <p>Node IP Address:<?php echo $rownode['ip_address'];?> </p>
     
      <hr class="d-sm-none">
    </div>
    <div class="col-sm-8">
      <h2>Start the Test</h2>
      <p>Read instruction before preceding </p>
      <p>1. Check Node Name</p>
      <p>2. Always verify Device Status</p>
      <br>
      
      <div class="container">
  <h2>The Real Time Quality Data is Sent</h2>         
  <table class="table">
    <thead>
      <tr>
        <th>Water PH value</th>
        <th>Temperature</th>
        <th>Turbidity</th>
        <th>Time</th>
		<th>Date</th>
      </tr>
    </thead>
     <tbody>
	<?php
	$sqldatanode = "SELECT * FROM data_table WHERE node_id='$node_id'";
    $resultdatanode = $conn->query($sqldatanode);

    if ($resultdatanode->num_rows > 0) {
    // output data of each row
    while($rowdatanode = $resultdatanode->fetch_assoc()) {
	?>
	 
      <tr>
        <td><?php echo $rowdatanode['ph_value']; ?></td>
        <td><?php echo $rowdatanode['temperature']; ?></td>
        <td><?php echo $rowdatanode['turbidity_value']; ?></td>
        <td><?php echo $rowdatanode['time']; ?></td>
        <td><?php echo $rowdatanode['Date']; ?></td>
      </tr>
      <?php 
	}
	}
	  ?>
    </tbody>
  </table>
</div>
      
      
      
      
    <a class="btn btn-primary" href="CsvDownload.php?node_id=<?php ?>" role="button">Download Dataset</a>
     </div>
  </div>
</div>

<?php require('footer.php'); ?>

</body>
</html>

<?php
}
}
  
}
}
  
  
  }
   else {
	   header("location: index.php");
   }


?>