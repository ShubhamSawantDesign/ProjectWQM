<?php
require_once("dbconnect.php");
$node_id = $_POST['node_id'];
$ipaddress = $_POST['ipaddress'];
$location = $_POST['location'];
$status = $_POST['status'];

$sqlselect = "SELECT * FROM table_node WHERE node_id='$node_id'";
$result = $conn->query($sqlselect);

if ($result->num_rows == 0) {

$sqlInsert = "INSERT INTO table_node(node_id, ip_address, location, status) VALUES ('$node_id', '$ipaddress', '$location', '$status');";


if ($conn->query($sql) === TRUE) {
                  echo "<script>alert('Node Added..!');</script>";
				  echo "<script>window.location.replace('NewUserAdd.php?Added=success');</script>";	
}
else
{
	              echo "<script>alert('Error in Adding Node..!');</script>";
				  echo "<script>window.location.replace('NewUserAdd.php?error');</script>";	
}
}
else
	{
		          echo "<script>alert('Node Details Available in DB please Update Details..!');</script>";
				  echo "<script>window.location.replace('NewUserAdd.php?duplicate');</script>";
	}
?>