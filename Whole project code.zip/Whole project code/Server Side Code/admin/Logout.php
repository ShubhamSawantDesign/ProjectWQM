<?php
session_start();
unset($_SESSION["token"]);
header("location: Index.php");

?>