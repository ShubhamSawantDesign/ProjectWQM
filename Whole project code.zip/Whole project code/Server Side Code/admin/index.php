<?php



?>

<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Welcome to Water Quality Management Admi Panel</title>
   <!-- <link rel="stylesheet" type="text/css" href="CSS/alignment.css"> -->

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  
</head>
<body>

<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <a class="navbar-brand" href="#">Admin Control Panel</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="#">This is Admin Panel</a>
      </li>
        
    </ul>
  </div>  
</nav>




<div class="container" style="margin-top:30px">
  <div class="row">
    <div class="col-sm-4">
    <img src="images/secure-login.jpg" alt="Secure Login" style="width:128px;height:128px;">
      <h2>Admin Login System</h2>
      <div class="">Login To Access System</div>
      
      <form action="processAdminlogin.php" method="POST">
      <p>Admin ID</p>
      <input type="text" name="admin_id" required/><br>
      <p>Password</p>
      <input type="password" name="password" required/>
      <br><br>
      <input type="submit" name="btn-login" value="Login"/>
      <br>
      </form>
      
      
      <hr class="d-sm-none">
    </div>
    <div class="col-sm-8">
      <h2>Online Water Quality Management </h2>
      <h5>Description</h5>
      <p>The Online Water Quality Management system is designed to monitor real time water Quality using Different Nodes at Different Location.</p>
      <p>After Login you will see the list of nodes with their installation location and IP address click on the node id to get real time status.</p>
      <p>You can download the CSV based Data Set and used it for data Analysis</p>
      <p>Do-not share User-id and Password with any one</p>
      <p>Always Access Portal on Secure Network</p>
      <p>If any issue occurs Contact System Administrator</p>
      <br>
      <br>
      
      <h2>Powered By</h2>
      <h5></h5>
      <p>Java J2SE J2ME.</p>
      <p>MY SQL SERVER</p>
      <br>
      <br>
      
    </div>
  </div>
</div>

<?php require("footer.php");  ?>

</body>
</html>