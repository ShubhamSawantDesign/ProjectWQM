<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <a class="navbar-brand" href="Home.php">Welcome </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="NewNodeAdd.php">Add New Node</a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="#">Add new USER</a>
      </li> 
      <li class="nav-item">
        <a class="nav-link" href="ViewNodes.php">View Node</a>
      </li>   
	  <li class="nav-item">
        <a class="nav-link" href="Logout.php">Logout</a>
      </li> 
    
	</ul>
  </div>  
</nav>