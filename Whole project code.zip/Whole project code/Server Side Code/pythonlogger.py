#This is the project code which will show us tubidity ph and temperature of water We will use the GPIO pins for 
#device communication SPI Communication Protocol will be usefull to have interface from MCP3008 Connected 
#Devices One_wire protocol will be used in order to gate temperature data from DS18B20 Temperature Sensor
import os
import glob
import requests
import Adafruit_GPIO.SPI as SPI
import Adafruit_MCP3008
import datetime
from time import sleep
from sendSms import sendTextmessage
tempdatetimeobj = datetime.datetime.now()

#One Wire Protocol Commands
os.system('modprobe w1-gpio')
os.system('modprobe w1-therm')

base_dir = '/sys/bus/w1/devices/'
device_folder = glob.glob(base_dir + '28*')[0]
device_file = device_folder + '/w1_slave'
#End of Commands
# Hardware SPI configuration:
SPI_PORT = 0 
SPI_DEVICE = 0 
mcp = Adafruit_MCP3008.MCP3008(spi=SPI.SpiDev(SPI_PORT, SPI_DEVICE))
#end of MCP Function
def getPhData():
    phsensorvalue = mcp.read_adc(0)
    miliVolts =(3.3/1023.00*phsensorvalue)
    answer = 3.5*miliVolts
    phvalue = "{:.2f}".format(answer)
    return phvalue 
          
def getTurbidityData():
            turbiditySensorvalue = mcp.read_adc(1)
            voltage = turbiditySensorvalue * (5.0/1023.0)
            calval = 100-(voltage/4.84)*100
            turbidity = "{:.2f}".format(calval)
            return turbidity
         
def read_temp_raw():
    f = open(device_file, 'r')
    lines = f.readlines()
    f.close()
    return lines
         
def read_temp():
    lines = read_temp_raw()
    while lines[0].strip()[-3:] != 'YES':
        time.sleep(0.2)
        lines = read_temp_raw()
    equals_pos = lines[1].find('t=')
    if equals_pos != -1:
        temp_string = lines[1][equals_pos+2:]
        temp_c = float(temp_string) / 1000.0
        temp_f = temp_c * 9.0 / 5.0 + 32.0
        tempindeg = "{:.2f}".format(temp_c)
        tempinfer = "{:.2f}".format(temp_f)
        return tempindeg

def sendData(ph, tempvalue, turvalue, timevalue, datevalue):
    userdata = {"phvalue": ph, "temp": tempvalue, "tur": turvalue, "time": timevalue, "date": datevalue, "nodeid":"N345"}
    resp = requests.post('http://192.168.0.100/wqm/handler.php', params=userdata)
    print(resp.text)

def checkPh(ph):
    phvalue = float(ph)
    if phvalue < 6.5:
        sendTextmessage(content='Water is getting Acidic')
        return 'Water is getting basic'
    elif phvalue > 8.5:
        sendTextmessage(content='Water is getting Basic')
        return 'Water getting basic'        
    else:
        return 'PH Parmeter is ok'

def checkTemp(temp):

    temperature = float(temp)
    if temperature < 15:
        sendTextmessage(content='Temperature is not ok its Cool please have a look')
        return 'Temperature is not ok its chilled'
    elif temperature > 26:
        sendTextmessage(content='Temperature is not ok its Hot')
        return 'Temperature is not ok its warm'    
    elif temperature > 15.00 and temperature < 26.00:
        return 'Temperature is ok within excepted params'
    else:
        return 'Temperature of Water is in expected Parameter'    

def checkTur(tur):
    turbidity = float(tur)
    if turbidity > 50:
        sendTextmessage(content='The water is muddy please Check the water supply ')
        return 'The water is quite muddy'
    elif turbidity > 20:
        sendTextmessage(content='The water is little Muddy')
        return 'Water is little bit muddy'
    else:
         return 'Water turbidity is in expected Parameter its clear....!'
         
         
try:
     while True:
         print("#################")
         print("Water Details are")
         
         temp = str(read_temp())
         phvalue = str(getPhData())
         tur = str(getTurbidityData())
         time = '{:%H:%M }'.format(datetime.datetime.now())
         date = '{:%d-%m-%Y }'.format(datetime.datetime.now())
        # print('Date is' + tempdatetimeobj.strftime("%x") + 'Time is' + tempdatetimeobj.strftime("%X"))
         print("Date is:-" + date + "Time is:- " + time)
         print("PH of water is:- " + phvalue + " Turbidity is:- "+ tur + "Temperature is:- " + temp)
         print(checkPh(ph=phvalue))
         print(checkTemp(temp=temp))
         print(checkTur(tur=tur))
         sendData(ph=phvalue, tempvalue=temp, turvalue=tur, timevalue=time, datevalue=date)
        
        
         print("#################")
         sleep(60)
          
except KeyboardInterrupt:
 print('unHandled Exception Occured')
          
