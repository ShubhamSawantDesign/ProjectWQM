<?php
header('Content-Type:application/json');
define('DB_HOST','localhost');
define('DB_USERNAME','wqm');
define('DB_PASSWORD','wqm');
define('DB_NAME','wqm');

$mysqli= new mysqli(DB_HOST,DB_USERNAME,DB_PASSWORD,DB_NAME);

if(!$mysqli){
die('Connection failed');
}

$node_id = $_COOKIE['node_id'];

$query = sprintf("select Date,temperature,ph_value,turbidity_value from data_table where time='6:00' AND node_id='$node_id'");
$query1 = sprintf("select Date,temperature,ph_value,turbidity_value from data_table where time='12:00' AND node_id='$node_id'");
$query2 = sprintf("select Date,temperature,ph_value,turbidity_value from data_table where time='18:00' AND node_id='$node_id'");
$query3 = sprintf("select Date,temperature,ph_value,turbidity_value from data_table where time='23:00' AND node_id='$node_id'");
$result = $mysqli->query($query);
$result1 = $mysqli->query($query1);
$result2 = $mysqli->query($query2);
$result3 = $mysqli->query($query3);
$data = array();
$data1 = array();
$data2 = array();
$data3 = array();
foreach ($result as $row){
$data[] = $row;
}
$result->close();
foreach ($result1 as $row){
$data1[] = $row;
}
$result1->close();
foreach ($result2 as $row){
$data2[] = $row;
}
$result2->close();
foreach ($result3 as $row){
$data3[] = $row;
}
$result3->close();
$mysqli->close();
$data5=array("first"=>$data,"second"=>$data1,"third"=>$data2,"fourth"=>$data3);
print json_encode($data5);