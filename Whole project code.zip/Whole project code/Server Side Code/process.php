<?php
session_start();
require_once("dbconnect.php");
$username = $_POST['user_id'];
$password  = $_POST['password'];

$sql = "SELECT * FROM login_table WHERE user_name='$username'";
$result = $conn->query($sql);

  if($result->num_rows > 0)
	{ 
      if($row = $result->fetch_assoc())
	  {
         if($row['type']=='1')
		 {
			 if($row['password']==$password)
			 {
			   $_SESSION['token']=$row['id'];
			   echo "<script>window.location.replace('Home.php');</script>";
			 } 
			  else 
			  {
				  echo "<script>alert('Password Wrong..!');</script>";
                  echo "<script>window.location.replace('index.php');</script>";			
			}
		}
          else
		  {
			  echo "<script>alert('You dont have proper priviledge to Access Section..!');</script>";
			  echo "<script>window.location.replace('index.php');</script>";
		  }
	  }
	    else
		     {		 
		       echo "User didn't Found..!";
			   echo "<script>window.location.replace('index.php');</script>";
		     }
	}
	  else{
		  
		  echo "<script>alert('User didn't found..!');</script>";
		  echo "<script>window.location.replace('index.php');</script>";
	  }

?>