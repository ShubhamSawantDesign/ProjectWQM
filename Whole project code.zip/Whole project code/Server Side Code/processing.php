<?php
$cookie_name = 'node_id';
$cookie_value = $_GET['node_id'];
setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/");
header("location: Graphs.php");

?>