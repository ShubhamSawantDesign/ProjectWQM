$(document).ready(function(){
	$.ajax({
		url:"data.php",
		method:"GET",
		success: function(data){
			console.log(data);
			var time = [];
			var temperature = [];
			var ph = [];
			var turbidity = [];
			for(var i in data["first"]){
			time.push("Date " + data["first"][i]["Date"]);
			temperature.push(data["first"][i].temperature);
			ph.push(data["first"][i].ph_value);
			turbidity.push(data["first"][i].turbidity_value);
			}
			
			var TMdataFirst = {
                label: "Temperature (6 AM)",
                data: temperature,
                lineTension: 0,
                //fill: false,
                borderColor: 'red'
            };
            var PdataFirst = {
                label: "Ph (6 AM)",
                data: ph,
                lineTension:0,
                borderColor:'red'
            };
            var TUdataFirst = {
                label: "Turbidity (6 AM)",
                data: turbidity,
                lineTension:0,
                borderColor: 'red'
            };
            
            
            var temperature1 = [];
			var ph1 = [];
			var turbidity1 = [];
            for(var i in data["second"]){
			    //time.push("Date " + data["second"][i]["Date"]);
			    temperature1.push(data["second"][i].temperature);
			    ph1.push(data["second"][i].ph_value);
			    turbidity1.push(data["second"][i].turbidity_value);
			}
            var TMdataSecond = {
                label: "Temperature (12 PM)",
                data: temperature1,
                lineTension: 0,
                //fill: false,
                borderColor: 'blue'
            };
            var PdataSecond = {
                label: "Ph (12 PM)",
                data: ph1,
                lineTension:0,
                borderColor:'blue'
            };
            var TUdataSecond = {
                label: "Turbidity (12 PM)",
                data: turbidity1,
                lineTension:0,
                borderColor: 'blue'
            };
    
            var temperature2 = [];
			var ph2 = [];
			var turbidity2 = [];
            for(var i in data["third"]){
			    //time.push("Date " + data["third"][i]["Date"]);
			    temperature2.push(data["third"][i].temperature);
			    ph2.push(data["third"][i].ph_value);
			    turbidity2.push(data["third"][i].turbidity_value);
			}
    
    
            var TMdataThird = {
                label: "Temperature (6 PM)",
                data: temperature2,
                lineTension: 0,
                //fill: false,
                borderColor: 'green'
            };
            var PdataThird = {
                label: "Ph (6 PM)",
                data: ph2,
                lineTension:0,
                borderColor:'green'
            };
            var TUdataThird = {
                label: "Turbidity (6 PM)",
                data: turbidity2,
                lineTension:0,
                borderColor: 'green'
            };
    
    
            var temperature3 = [];
			var ph3 = [];
			var turbidity3 = [];
            for(var i in data["fourth"]){
			    //time.push("Date " + data["fourth"][i]["Date"]);
			    temperature3.push(data["fourth"][i].temperature);
			    ph3.push(data["fourth"][i].ph_value);
			    turbidity3.push(data["fourth"][i].turbidity_value);
			}
    
    
            var TMdataFourth = {
                label: "Temperature (11 PM)",
                data: temperature3,
                lineTension: 0,
                //fill: false,
                borderColor: 'grey'
            };
            var PdataFourth = {
                label: "Ph (11 PM)",
                data: ph3,
                lineTension:0,
                borderColor:'grey'
            };
            var TUdataFourth = {
                label: "Turbidity (11 PM)",
                data: turbidity3,
                lineTension:0,
                borderColor: 'grey'
            };
    
            console.log(TMdataFirst,TMdataSecond,TMdataThird,TMdataFourth);
            var chartdatatemp = {
				labels: time,
				datasets:[
				TMdataFirst,TMdataSecond,TMdataThird,TMdataFourth]
			};
    
            var ctxt = $("#temperature");
			
			var barGrapht = new Chart(ctxt, {
				type:'line',//bar,pie,line,doughnut
				data: chartdatatemp
			});
			
			var chartdataph = {
				labels: time,
				datasets:[
				PdataFirst,PdataSecond,PdataThird,PdataFourth]
			};
			
			var ctxp = $("#ph");
			var barGraphp = new Chart(ctxp, {
				type:'line',//bar,pie,line,doughnut
				data: chartdataph
			});
			var chartdatatur = {
				labels: time,
				datasets:[
				TUdataFirst,TUdataSecond,TUdataThird,TUdataFourth]
			};
			var ctxtu = $("#turbidity");
			var barGraphtu = new Chart(ctxtu, {
				type:'line',//bar,pie,line,doughnut
				data: chartdatatur
			});
			/*
			var chartdatatemp = {
				labels: time,
				datasets:[
				{
					label:"Water Temperature",
					backgroundColor: 'rgba(200,200,200,0.75)',
					borderColor: 'rgba(200,200,200,0.75)',
					hoverBackgroundColor: 'rgba(200,200,200,1)',
					hoverBorderColor: 'rgba(200,200,200,0.75)',
					data: temperature
				}]
			};
			*/
			
			/*var dataFirst = {
    label: "Temperature (March)",
    data: temperature,
    lineTension: 0,
    //fill: false,
    borderColor: 'red'
  };

var dataSecond = {
    label: "Temperature (December)",
    data: ph,
    lineTension: 0,
    //fill: false,
  borderColor: 'blue'
  };
  var dataThird = {
    label: "Temperature (April)",
    data: ph,
    lineTension: 0,
    //fill: false,
  borderColor: 'green'
  };
			
			var chartdatatemp = {
				labels: time,
				datasets:[
				dataFirst,dataSecond,dataThird]
			};
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			var chartdataph = {
				labels: time,
				datasets:[
				{
					label:"Water Ph",
					backgroundColor: 'rgba(200,200,200,0.75)',
					borderColor: 'rgba(200,200,200,0.75)',
					hoverBackgroundColor: 'rgba(200,200,200,1)',
					hoverBorderColor: 'rgba(200,200,200,0.75)',
					data: ph
				}]
			};
			var chartdatatur = {
				labels: time,
				datasets:[
				{
					label:"Water Turbidity",
					backgroundColor: 'rgba(200,200,200,0.75)',
					borderColor: 'rgba(200,200,200,0.75)',
					hoverBackgroundColor: 'rgba(200,200,200,1)',
					hoverBorderColor: 'rgba(200,200,200,0.75)',
					data: turbidity
				}]
			};
			
			var ctxt = $("#temperature");
			var ctxp = $("#ph");
			var ctxtu = $("#turbidity");
			
			var barGrapht = new Chart(ctxt, {
				type:'line',//bar,pie,line,doughnut
				data: chartdatatemp
			});
			var barGraphp = new Chart(ctxp, {
				type:'line',//bar,pie,line,doughnut
				data: chartdataph
			});
			var barGraphtu = new Chart(ctxtu, {
				type:'line',//bar,pie,line,doughnut
				data: chartdatatur
			});
		},
		error: function(data){
			console.log(data);
		}
		*/
		},
		error: function(data){
			console.log(data);
		}
	});

});