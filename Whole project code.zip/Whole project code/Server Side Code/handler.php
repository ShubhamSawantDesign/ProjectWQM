<?php 
require 'dbconnect.php';

$phvalue = ($_GET["phvalue"]);

$temp = ($_GET["temp"]);

$tur = ($_GET["tur"]);

$time = $_GET["time"];

$date = $_GET["date"];

$nodeid =  $_GET["nodeid"];

$sql = "INSERT INTO data_table(temperature, ph_value, turbidity_value, time, Date, node_id) VALUES ('$temp', '$phvalue', '$tur', '$time', '$date', '$nodeid');";


if ($conn->query($sql) === TRUE) {
    //echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

?>