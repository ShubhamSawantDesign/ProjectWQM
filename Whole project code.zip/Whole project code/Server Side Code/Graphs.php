<!DOCTYPE html>
<html lang="en">
<head>
  <title>Graph For <?php echo $_COOKIE['node_id']?></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <style>
	#chart-container{
	width:640px;
	height:auto;
	}
	</style>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<?php require('header.php'); ?>
<div class="container" style="margin-top:30px">
  <div class="row">
    <div class="col-sm-4">
      <h2>User Information</h2>
      <p>Graphs for <?php echo $_COOKIE['node_id'];?></p>
      
     
      <hr class="d-sm-none">
    </div>
    <div class="col-sm-8">
      <p>Read instruction before preceding </p>
      <p>1. Graphs are generated as per values in Database</p>
      <br>
      
      <div class="container">        
 
 <div id="chart-container">
		<canvas id="temperature"></canvas>
		</div>
		<br/>
		<div id="chart-container">
		<canvas id="ph"></canvas>
		</div>
		<br/>
		<div id="chart-container">
		<canvas id="turbidity"></canvas>
		</div>
		
		<script type="text/javascript" src="jquery.min.js"></script>
		<script type="text/javascript" src="Chart.min.js"></script>
		<script type="text/javascript" src="app.js"></script>
		</div>
 
</div>
      
      
      
      
    
    
     </div>
  </div>
</div>
<?php require("footer.php")  ?>

</body>
</html>