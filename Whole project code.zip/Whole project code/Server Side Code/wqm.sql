-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 05, 2020 at 12:23 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wqm`
--

-- --------------------------------------------------------

--
-- Table structure for table `data_table`
--

CREATE TABLE `data_table` (
  `entry_id` int(11) NOT NULL,
  `temperature` varchar(200) NOT NULL,
  `ph_value` varchar(200) NOT NULL,
  `turbidity_value` varchar(200) NOT NULL,
  `time` varchar(200) NOT NULL,
  `Date` varchar(200) NOT NULL,
  `node_id` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_table`
--

INSERT INTO `data_table` (`entry_id`, `temperature`, `ph_value`, `turbidity_value`, `time`, `Date`, `node_id`) VALUES
(30, '25.81', '6.89', '4.87', '16:56 ', '26-03-2020 ', 'N345'),
(31, '25.81', '6.91', '4.77', '16:57 ', '26-03-2020 ', 'N345'),
(32, '25.88', '6.89', '4.57', '16:58 ', '26-03-2020 ', 'N345'),
(33, '25.88', '6.90', '4.97', '16:59 ', '26-03-2020 ', 'N345'),
(34, '25.81', '6.89', '4.87', '17:00 ', '26-03-2020 ', 'N345'),
(35, '25.88', '6.90', '4.97', '17:01 ', '26-03-2020 ', 'N345'),
(36, '26.00', '6.88', '4.97', '17:02 ', '26-03-2020 ', 'N345'),
(37, '25.81', '6.91', '5.08', '17:03 ', '26-03-2020 ', 'N345'),
(38, '25.62', '6.90', '4.97', '17:05 ', '26-03-2020 ', 'N345'),
(39, '18.94', '6.95', '4.67', '17:06 ', '26-03-2020 ', 'N345'),
(40, '16.81', '6.98', '2.96', '17:08 ', '26-03-2020 ', 'N345'),
(41, '16.75', '6.98', '2.45', '17:08 ', '26-03-2020 ', 'N345'),
(42, '16.81', '6.97', '1.95', '17:09 ', '26-03-2020 ', 'N345'),
(43, '17.12', '6.99', '1.54', '17:10 ', '26-03-2020 ', 'N345'),
(44, '17.44', '6.95', '1.54', '17:11 ', '26-03-2020 ', 'N345'),
(45, '17.56', '6.98', '1.74', '17:12 ', '26-03-2020 ', 'N345'),
(46, '17.75', '6.95', '1.44', '17:14 ', '26-03-2020 ', 'N345'),
(47, '18.00', '6.98', '1.84', '17:15 ', '26-03-2020 ', 'N345'),
(48, '18.12', '6.97', '1.84', '17:16 ', '26-03-2020 ', 'N345'),
(49, '18.38', '6.99', '1.74', '17:17 ', '26-03-2020 ', 'N345'),
(50, '18.50', '6.95', '1.54', '17:18 ', '26-03-2020 ', 'N345'),
(51, '18.69', '6.95', '1.64', '17:19 ', '26-03-2020 ', 'N345'),
(52, '18.81', '6.94', '1.54', '17:20 ', '26-03-2020 ', 'N345'),
(53, '19.00', '6.94', '1.44', '17:21 ', '26-03-2020 ', 'N345'),
(54, '19.19', '6.93', '1.44', '17:22 ', '26-03-2020 ', 'N345'),
(55, '19.38', '6.94', '1.14', '17:23 ', '26-03-2020 ', 'N345'),
(56, '19.50', '6.90', '1.24', '17:24 ', '26-03-2020 ', 'N345'),
(57, '19.69', '6.95', '1.64', '17:25 ', '26-03-2020 ', 'N345'),
(58, '19.75', '6.93', '1.44', '17:26 ', '26-03-2020 ', 'N345'),
(59, '19.94', '6.92', '1.34', '17:27 ', '26-03-2020 ', 'N345'),
(60, '20.19', '6.90', '1.24', '17:28 ', '26-03-2020 ', 'N345'),
(61, '20.25', '6.95', '1.34', '17:29 ', '26-03-2020 ', 'N345'),
(62, '20.38', '6.90', '1.34', '17:30 ', '26-03-2020 ', 'N345'),
(63, '20.50', '6.94', '1.24', '17:31 ', '26-03-2020 ', 'N345');

-- --------------------------------------------------------

--
-- Table structure for table `login_table`
--

CREATE TABLE `login_table` (
  `id` int(11) NOT NULL,
  `user_name` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `type` int(200) NOT NULL,
  `last_login` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login_table`
--

INSERT INTO `login_table` (`id`, `user_name`, `password`, `type`, `last_login`) VALUES
(1, 'test', 'test', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `table_node`
--

CREATE TABLE `table_node` (
  `id` int(11) NOT NULL,
  `node_id` varchar(200) NOT NULL,
  `ip_address` varchar(200) NOT NULL,
  `location` varchar(200) NOT NULL,
  `status` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `table_node`
--

INSERT INTO `table_node` (`id`, `node_id`, `ip_address`, `location`, `status`) VALUES
(1, 'N345', '192.168.0.104', 'Pune, Bibwewadi', '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `data_table`
--
ALTER TABLE `data_table`
  ADD PRIMARY KEY (`entry_id`);

--
-- Indexes for table `login_table`
--
ALTER TABLE `login_table`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `table_node`
--
ALTER TABLE `table_node`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `data_table`
--
ALTER TABLE `data_table`
  MODIFY `entry_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT for table `login_table`
--
ALTER TABLE `login_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `table_node`
--
ALTER TABLE `table_node`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
