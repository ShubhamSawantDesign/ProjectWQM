<?php 
require 'dbconnect.php';

$nodeid = $_GET['nodeid'];
$ipaddress = $_GET['ipaddress'];

$sqlupdate = "UPDATE table_node SET ip_address='$ipaddress' WHERE node_id='$nodeid'";

if ($conn->query($sqlupdate) === TRUE) {
 //   echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
}



?>